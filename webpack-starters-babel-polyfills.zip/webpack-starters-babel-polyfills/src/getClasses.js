import { wizard } from "./wizard";
import { barbarian } from "./barbarian";

function getClasses() {
  console.log("get classes was called");
  console.log(wizard);
  console.log(barbarian);
}

export default getClasses;
